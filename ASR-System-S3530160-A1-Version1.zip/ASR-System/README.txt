Name: Elliot Schot
RMIT Email: s3530160@student.rmit.edu.au
Group: No Group
GIT LINK: https://gitlab.com/ElliotSchotRMIT/COSC2276 [Currently Private]

Coding patterns: TODO

Prototype: Used my User.cs -> Staff.cs/Student.cs classes
	Analytical justification
	What advantages do they offer? 
	
Observer: Used in [x]Manager.cs classes
	Analytical justification: It allows the Engine to view SQL data [x]Manager.[x]List and to create/delete/update the data in the SQL backend by [x]List.Update